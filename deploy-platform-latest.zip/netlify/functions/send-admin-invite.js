/**
 * POST /.netlify/functions/send-admin-invite
 *
 * Sends a staff invite via Supabase's inviteUserByEmail API.
 * This uses the Supabase "Invite" email template — a separate template from
 * the OTP / Magic Link template that the farmer app uses — so you can
 * customise the two independently in Supabase → Auth → Email Templates.
 *
 * Input  (JSON): {
 *   email:       string,          // invitee email
 *   redirectTo:  string,          // where the magic-link lands (index.html)
 *   data: {                       // written to auth.users.user_metadata
 *     full_name, role, phone, invited_by, invited_at, outlet_id, status
 *   }
 * }
 * Output (JSON):
 *   { ok: true }
 *   { ok: false, error: string }
 *
 * Required Netlify env vars: SUPABASE_URL, SUPABASE_SERVICE_KEY
 */

const CORS = {
  'Access-Control-Allow-Origin':  '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type':                  'application/json',
};

function reply(statusCode, body) {
  return { statusCode, headers: CORS, body: JSON.stringify(body) };
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: CORS, body: '' };
  if (event.httpMethod !== 'POST')   return reply(405, { ok: false, error: 'POST required' });

  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_KEY) {
    return reply(500, { ok: false, error: 'Server not configured (SUPABASE_URL / SUPABASE_SERVICE_KEY missing).' });
  }

  let body = {};
  try { body = JSON.parse(event.body || '{}'); } catch (_) {}

  const email      = String(body.email      || '').trim().toLowerCase();
  const redirectTo = String(body.redirectTo || '').trim();
  const data       = body.data || {};

  if (!email || !email.includes('@')) {
    return reply(400, { ok: false, error: 'Valid email required.' });
  }

  try {
    /* Supabase Admin → invite user.
       This sends the "Invite" email template (Auth → Email Templates → Invite)
       which is separate from the OTP/Magic Link template the farmer app uses.
       Customise the Invite template in Supabase to say "web admin" language. */
    const res = await fetch(`${process.env.SUPABASE_URL}/auth/v1/invite`, {
      method:  'POST',
      headers: {
        apikey:          process.env.SUPABASE_SERVICE_KEY,
        Authorization:  `Bearer ${process.env.SUPABASE_SERVICE_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email,
        data,
        ...(redirectTo ? { redirect_to: redirectTo } : {}),
      }),
    });

    const text = await res.text();
    let json;
    try { json = text ? JSON.parse(text) : {}; } catch (_) { json = {}; }

    if (!res.ok) {
      /* 422 means the user already exists — Supabase still sends them an
         invite/magic-link email, so this is effectively a resend. Treat it
         as success so the admin doesn't see a confusing error. */
      if (res.status === 422) {
        /* Re-send using signInWithOtp instead (works for existing users) */
        const otpRes = await fetch(`${process.env.SUPABASE_URL}/auth/v1/otp`, {
          method:  'POST',
          headers: {
            apikey:          process.env.SUPABASE_SERVICE_KEY,
            Authorization:  `Bearer ${process.env.SUPABASE_SERVICE_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ email, create_user: false }),
        });
        if (!otpRes.ok) {
          const otpText = await otpRes.text();
          console.error('[send-admin-invite] resend OTP failed', otpRes.status, otpText);
        }
        return reply(200, { ok: true, resent: true });
      }
      console.error('[send-admin-invite] invite failed', res.status, text);
      return reply(res.status, { ok: false, error: json?.msg || json?.message || `Invite failed (${res.status})` });
    }

    return reply(200, { ok: true });
  } catch (e) {
    console.error('[send-admin-invite] unhandled', e);
    return reply(500, { ok: false, error: 'Internal error: ' + (e?.message || String(e)) });
  }
};
